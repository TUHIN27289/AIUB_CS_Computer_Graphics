#include<iostream>
#include<windows.h>
#include<windows.h>
#include<cstdio>
#include<MMSystem.h>
#include<GL\glut.h>
#include <GL/glu.h>
#include<math.h>
#include <stdlib.h>
#include<stdio.h>
#define PI 3.1416

using namespace std;
GLint i, j;
bool f=true;

GLint pos_car1, pos_car2 = 0;
GLint car1_speed = 2;
float pos1=0,pos3=600,pos2=400;
float speed1=2.9f,speed2=2.5f,speed3=1.95f,cpos1=200,cpos2=450,cpos3=-250,cpos4=50,cpos5=490,sp1=2.0f;
float sun_x=620 ,sun_y=380,sp_x=0.5f,sp_y=1.0f;


void init()
{
	glClearColor(157.0f/255.0f, 216.0f/255.0f, 250.0f/255.0f, 1.0); //157, 216, 250
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0.0, 1200.0, 0.0, 600.0);
}

/// Field_Model
void Field(){


    ///Field - Shading
    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(50, 205, 50);///green

	glVertex2i(0, 0);
	glVertex2i(0, 50);
	glVertex2i(1200, 50);
	glVertex2i(1200, 0);
	glEnd();
	glPopMatrix();
}



///Road
void Road()
{
    glPushMatrix();
    glBegin(GL_POLYGON);
    if(f) glColor3f(0.43, 0.43, 0.43);
    else glColor3f(0.23,0.23,0.23);
	glVertex2i(0, 50);
	glVertex2i(0, 150);
	glVertex2i(1200, 150);
	glVertex2i(1200, 50);
	glEnd();
	glPopMatrix();

	///divider
	glColor3f(0.83, 0.83, 0.83);
	glBegin(GL_LINES);
	for(j=0;j<=1000;j+=100) ///series of white lines
    {
        glVertex2i(20+j,100);
        glVertex2i(80+j,100);
    }
    glEnd();
}
///SOIL
void Field2()
{
    ///Field - Middle layer
    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(166, 125, 61);
	glVertex2i(0, 150);
	glVertex2i(0, 275);
	glVertex2i(1200, 275);
	glVertex2i(1200, 150);
	glEnd();
	glPopMatrix();
}



building2(){

    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(154,205,50);
    glVertex2i(802, 195);
    glVertex2i(1000, 195);
	glVertex2i(1000, 400);
	glVertex2i(802, 400);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(107,142,35);
    glVertex2i(787, 195);
    glVertex2i(877, 195);
	glVertex2i(877, 400);
	glVertex2i(787, 400);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(787, 195);
    glVertex2i(788, 195);
	glVertex2i(788, 400);
	glVertex2i(787, 400);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(777, 400);
    glVertex2i(1010, 400);
	glVertex2i(1010, 401);
	glVertex2i(777, 401);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(777, 390);
    glVertex2i(1010, 390);
	glVertex2i(1010, 391);
	glVertex2i(777, 391);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(773, 405);
    glVertex2i(774, 405);
	glVertex2i(774, 195);
	glVertex2i(773, 195);
	glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(765, 196);
    glVertex2i(1005, 196);
	glVertex2i(1005, 195);
	glVertex2i(765, 195);
	glEnd();
	glPopMatrix();


	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(765, 391);
    glVertex2i(1005, 391);
	glVertex2i(1005, 390);
	glVertex2i(765, 390);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(765, 342);
    glVertex2i(1005, 342);
	glVertex2i(1005, 343);
	glVertex2i(765, 343);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(765, 293);
    glVertex2i(1005, 293);
	glVertex2i(1005, 292);
	glVertex2i(765, 292);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(765, 244);
    glVertex2i(1005, 244);
	glVertex2i(1005, 245);
	glVertex2i(765, 245);
	glEnd();
	glPopMatrix();



     glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(877, 400);
    glVertex2i(878, 400);
	glVertex2i(878, 195);
	glVertex2i(877, 195);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(920, 400);
    glVertex2i(921, 400);
	glVertex2i(921, 195);
	glVertex2i(920, 195);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(960, 400);
    glVertex2i(961, 400);
	glVertex2i(961, 195);
	glVertex2i(960, 195);
	glEnd();
	glPopMatrix();


     glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(833, 400);
    glVertex2i(834, 400);
	glVertex2i(834, 195);
	glVertex2i(833, 195);
	glEnd();
	glPopMatrix();
///
	   glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(970, 380);
    glVertex2i(990, 380);
	glVertex2i(990, 355);
	glVertex2i(970, 355);
	glEnd();
	glPopMatrix();

	   glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(884, 380);
    glVertex2i(915, 380);
	glVertex2i(915, 355);
	glVertex2i(884, 355);
	glEnd();
	glPopMatrix();

	   glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(800, 380);
    glVertex2i(820, 380);
	glVertex2i(820, 355);
	glVertex2i(800, 355);
	glEnd();
	glPopMatrix();

	   glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(935, 380);
    glVertex2i(955, 380);
	glVertex2i(955, 355);
	glVertex2i(935, 355);
	glEnd();
	glPopMatrix();

	   glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(845, 380);
    glVertex2i(865, 380);
	glVertex2i(865, 355);
	glVertex2i(845, 355);
	glEnd();
	glPopMatrix();



///
	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(935, 331);
    glVertex2i(955, 331);
	glVertex2i(955, 306);
	glVertex2i(935, 306);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(845, 331);
    glVertex2i(865, 331);
	glVertex2i(865, 306);
	glVertex2i(845, 306);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(970, 331);
    glVertex2i(990, 331);
	glVertex2i(990, 306);
	glVertex2i(970, 306);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(884, 331);
    glVertex2i(915, 331);
	glVertex2i(915, 306);
	glVertex2i(884, 306);
	glEnd();
	glPopMatrix();
	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(800, 331);
    glVertex2i(820, 331);
	glVertex2i(820, 306);
	glVertex2i(800, 306);
	glEnd();
	glPopMatrix();
///
     glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(935, 282);
    glVertex2i(955, 282);
	glVertex2i(955, 257);
	glVertex2i(935, 257);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(845, 282);
    glVertex2i(865, 282);
	glVertex2i(865, 257);
	glVertex2i(845, 257);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(970, 282);
    glVertex2i(990, 282);
	glVertex2i(990, 257);
	glVertex2i(970, 257);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(884, 282);
    glVertex2i(915, 282);
	glVertex2i(915, 257);
	glVertex2i(884, 257);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(800, 282);
    glVertex2i(820, 282);
	glVertex2i(820, 257);
	glVertex2i(800, 257);
	glEnd();
	glPopMatrix();
	///

      glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(800, 233);
    glVertex2i(820, 233);
	glVertex2i(820, 208);
	glVertex2i(800, 208);
	glEnd();
	glPopMatrix();

      glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(845, 233);
    glVertex2i(865, 233);
	glVertex2i(865, 208);
	glVertex2i(845, 208);
	glEnd();
	glPopMatrix();
//middle
	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(884, 240);
    glVertex2i(915, 240);
	glVertex2i(915, 195);
	glVertex2i(884, 195);
	glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(935, 233);
    glVertex2i(955, 233);
	glVertex2i(955, 208);
	glVertex2i(935, 208);
	glEnd();
	glPopMatrix();




	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96,96);
    glVertex2i(970, 233);
    glVertex2i(990, 233);
	glVertex2i(990, 208);
	glVertex2i(970, 208);
	glEnd();
	glPopMatrix();










}

void soil(){


     glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(97, 131, 166);
    glVertex2i(765, 150);
    glVertex2i(1200, 150);
	glVertex2i(1200, 195);
	glVertex2i(765, 195);
	glEnd();
	glPopMatrix();




}


void building(){


	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(707, 405);
    glVertex2i(720, 405);
	glVertex2i(720, 385);
	glVertex2i(707, 385);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(743, 405);
    glVertex2i(755, 405);
	glVertex2i(755, 385);
	glVertex2i(743, 385);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(777, 405);
    glVertex2i(790, 405);
	glVertex2i(790, 385);
	glVertex2i(777, 385);
	glEnd();
	glPopMatrix();

	  glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(777, 375);
    glVertex2i(787, 375);
	glVertex2i(787, 355);
	glVertex2i(777, 355);
	glEnd();
	glPopMatrix();

    	  glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(777, 343);
    glVertex2i(787, 343);
	glVertex2i(787, 323);
	glVertex2i(777, 323);
	glEnd();
	glPopMatrix();

	  glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(777, 310);
    glVertex2i(787, 310);
	glVertex2i(787, 290);
	glVertex2i(777, 290);
	glEnd();
	glPopMatrix();

		  glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(777, 275);
    glVertex2i(787, 275);
	glVertex2i(787, 255);
	glVertex2i(777, 255);
	glEnd();
	glPopMatrix();



}

void Building1()
{


    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102, 205, 170);
    glVertex2i(700, 250);
    glVertex2i(802, 250);
	glVertex2i(802, 410);
	glVertex2i(700, 410);
	glEnd();
	glPopMatrix();




	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(707, 343);
    glVertex2i(720, 343);
	glVertex2i(720, 325);
	glVertex2i(707, 325);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(128, 128, 128);
    glVertex2i(733.5, 250);
    glVertex2i(734, 250);
	glVertex2i(734, 410);
	glVertex2i(733.5, 410);
	glEnd();
	glPopMatrix();

		 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(743, 343);
    glVertex2i(755, 343);
	glVertex2i(755, 325);
	glVertex2i(743, 325);
	glEnd();
	glPopMatrix();




	//green
	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(117,155,132);
    glVertex2i(797, 243);
    glVertex2i(690, 243);
	glVertex2i(690, 285);
	glVertex2i(797, 285);
	glEnd();
	glPopMatrix();



	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(707, 373);
    glVertex2i(720, 373);
	glVertex2i(720, 355);
	glVertex2i(707, 355);
	glEnd();
	glPopMatrix();




	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(707, 310);
    glVertex2i(720, 310);
	glVertex2i(720, 290);
	glVertex2i(707, 290);
	glEnd();
	glPopMatrix();


	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(743, 373);
    glVertex2i(755, 373);
	glVertex2i(755, 355);
	glVertex2i(743, 355);
	glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(743, 309);
    glVertex2i(755, 309);
	glVertex2i(755, 290);
	glVertex2i(743, 290);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(128, 128, 128);
    glVertex2i(700, 315);
    glVertex2i(802, 315);
	glVertex2i(802, 316);
	glVertex2i(700, 316);
	glEnd();
	glPopMatrix();

       glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(128, 128, 128);
    glVertex2i(700, 348);
    glVertex2i(802, 348);
	glVertex2i(802, 349);
	glVertex2i(700, 349);
	glEnd();
	glPopMatrix();



	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(128, 128, 128);
    glVertex2i(767.5, 240);
    glVertex2i(768, 240);
	glVertex2i(768, 410);
	glVertex2i(767.5, 410);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(128, 128, 128);
    glVertex2i(700, 380);
    glVertex2i(802, 380);
	glVertex2i(802, 381);
	glVertex2i(700, 381);
	glEnd();
	glPopMatrix();


///window
	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(743, 277);
    glVertex2i(755, 277);
	glVertex2i(755, 257);
	glVertex2i(743, 257);
	glEnd();
	glPopMatrix();

	 glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(707, 277);
    glVertex2i(720, 277);
	glVertex2i(720, 257);
	glVertex2i(707, 257);
	glEnd();
	glPopMatrix();



		glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(690, 240);
    glVertex2i(691, 240);
	glVertex2i(691, 352);
	glVertex2i(690, 352);
	glEnd();
	glPopMatrix();

		glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(690, 351);
    glVertex2i(735, 351);
	glVertex2i(735, 350);
	glVertex2i(690, 350);
	glEnd();
	glPopMatrix();

		glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(96,96, 96);
    glVertex2i(735, 240);
    glVertex2i(736, 240);
	glVertex2i(736, 352);
	glVertex2i(735, 352);
	glEnd();
	glPopMatrix();

	//////////////////////////////////////////


	  glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(199,120,38);
	glVertex2i(450, 200);
	glVertex2i(450, 415);
	glVertex2i(550, 415);
	glVertex2i(550, 200);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(300, 200);
	glVertex2i(300, 300);
	glVertex2i(450, 300);
	glVertex2i(450, 200);
	glEnd();


	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(50,92,116);
	glVertex2i(450, 200);
	glVertex2i(450, 400);
	glVertex2i(470, 400);
	glVertex2i(470, 200);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(50,92,116);
	glVertex2i(530, 200);
	glVertex2i(530, 400);
	glVertex2i(550, 400);
	glVertex2i(550, 200);
	glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(159,112,58);
	glVertex2i(300, 200);
	glVertex2i(300, 205);
	glVertex2i(550, 205);
	glVertex2i(550, 200);
    glEnd();
	glPopMatrix();



	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(450, 200);
	glVertex2i(450, 400);
	glVertex2i(456, 400);
	glVertex2i(456, 200);
    glEnd();
	glPopMatrix();


   glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(544, 200);
	glVertex2i(544, 400);
	glVertex2i(550, 400);
	glVertex2i(550, 200);
    glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);

	glVertex2i(464, 200);
	glVertex2i(464, 400);
	glVertex2i(470, 400);
	glVertex2i(470, 200);
    glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(530, 200);
	glVertex2i(530, 400);
	glVertex2i(536, 400);
	glVertex2i(536, 200);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(450, 230);
	glVertex2i(450, 240);
	glVertex2i(550, 240);
	glVertex2i(550, 230);
    glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(450, 270);
	glVertex2i(450, 280);
	glVertex2i(550, 280);
	glVertex2i(550, 270);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(450, 310);
	glVertex2i(450, 320);
	glVertex2i(550, 320);
	glVertex2i(550, 310);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(450, 350);
	glVertex2i(450, 360);
	glVertex2i(550, 360);
	glVertex2i(550, 350);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(450,390);
	glVertex2i(450, 400);
	glVertex2i(550, 400);
	glVertex2i(550, 390);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(199,120,38);
	glVertex2i(450,235);
	glVertex2i(550, 235);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(450,275);
	glVertex2i(550, 275);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(450,315);
	glVertex2i(550, 315);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(450,355);
	glVertex2i(550, 355);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(450,395);
	glVertex2i(550, 395);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(450,405);
	glVertex2i(550, 405);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(450,410);
	glVertex2i(550, 410);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(205,170,125);
	glVertex2i(450, 410);
	glVertex2i(450, 415);
	glVertex2i(550, 415);
	glVertex2i(550, 410);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(470, 415);
	glVertex2i(470, 430);
	glVertex2i(500, 430);
	glVertex2i(500, 415);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(550, 235);
	glVertex2i(550, 245);
	glVertex2i(560, 245);
	glVertex2i(560, 235);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(550, 275);
	glVertex2i(550, 285);
	glVertex2i(560, 285);
	glVertex2i(560, 275);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(550, 315);
	glVertex2i(550, 325);
	glVertex2i(560, 325);
	glVertex2i(560, 315);
    glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(550, 355);
	glVertex2i(550, 365);
	glVertex2i(560, 365);
	glVertex2i(560, 355);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(145,145,145);
	glVertex2i(460, 416);
	glVertex2i(540, 416);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(460, 418);
	glVertex2i(540, 418);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(460, 420);
	glVertex2i(540, 420);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(460, 422);
	glVertex2i(540, 422);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(460, 415);
	glVertex2i(460, 424);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(470, 415);
	glVertex2i(470, 424);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(480, 415);
	glVertex2i(480, 424);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(490, 415);
	glVertex2i(490, 424);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(500, 415);
	glVertex2i(500, 424);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(510, 415);
	glVertex2i(510, 424);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(520, 415);
	glVertex2i(520, 424);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(530, 415);
	glVertex2i(530, 424);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(540, 415);
	glVertex2i(540, 424);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 210);
	glVertex2i(450, 210);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glVertex2i(300, 215);
	glVertex2i(450, 215);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 220);
	glVertex2i(450, 220);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 225);
	glVertex2i(450, 225);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 230);
	glVertex2i(450, 230);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 235);
	glVertex2i(450, 235);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 240);
	glVertex2i(450, 240);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 245);
	glVertex2i(450, 245);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 250);
	glVertex2i(450, 250);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 255);
	glVertex2i(450, 255);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 260);
	glVertex2i(450, 260);
    glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 265);
	glVertex2i(450, 265);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 270);
	glVertex2i(450, 270);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 275);
	glVertex2i(450, 275);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 280);
	glVertex2i(450, 280);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 285);
	glVertex2i(450, 285);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 290);
	glVertex2i(450, 290);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 295);
	glVertex2i(450, 295);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(159,112,58);
	glVertex2i(300, 300);
	glVertex2i(450, 300);
    glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(102,102,102);
	glVertex2i(330, 215);
	glVertex2i(330, 230);
	glVertex2i(420, 230);
	glVertex2i(420, 215);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(330, 250);
	glVertex2i(330, 265);
	glVertex2i(420, 265);
	glVertex2i(420, 250);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(159,112,58);
	glVertex2i(300, 200);
	glVertex2i(300, 300);
	glVertex2i(305, 300);
	glVertex2i(305, 200);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(320, 200);
	glVertex2i(320, 300);
	glVertex2i(330, 300);
	glVertex2i(330, 200);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(345, 200);
	glVertex2i(345, 300);
	glVertex2i(355, 300);
	glVertex2i(355, 200);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(370, 200);
	glVertex2i(370, 300);
	glVertex2i(380, 300);
	glVertex2i(380, 200);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(395, 200);
	glVertex2i(395, 300);
	glVertex2i(405, 300);
	glVertex2i(405, 200);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(420, 200);
	glVertex2i(420, 300);
	glVertex2i(430, 300);
	glVertex2i(430, 200);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(139,87,63);
	glVertex2i(300, 232);
	glVertex2i(300, 238);
	glVertex2i(450, 238);
	glVertex2i(450, 232);
    glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(300, 272);
	glVertex2i(300, 278);
	glVertex2i(450, 278);
	glVertex2i(450, 272);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(102,102,102);
	glVertex2i(305, 278);
	glVertex2i(305, 300);
	glVertex2i(350, 300);
	glVertex2i(350, 278);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(355, 285);
	glVertex2i(355, 300);
	glVertex2i(370, 300);
	glVertex2i(370, 285);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(375, 278);
	glVertex2i(375, 300);
	glVertex2i(400, 300);
	glVertex2i(400, 278);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(405, 285);
	glVertex2i(405, 300);
	glVertex2i(420, 300);
	glVertex2i(420, 285);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(300, 300);
	glVertex2i(300, 330);
	glVertex2i(450, 330);
	glVertex2i(450, 300);
    glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
	glVertex2i(375, 330);
	glVertex2i(375, 360);
	glVertex2i(450, 360);
	glVertex2i(450, 330);
    glEnd();
	glPopMatrix();
///...........///

    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(116,187,251);
	glVertex2i(315, 308);
	glVertex2i(315, 325);
	glVertex2i(350, 325);
	glVertex2i(350, 308);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110,123,139);
	glVertex2i(305, 278);
	glVertex2i(305, 400);
	glVertex2i(308, 400);
	glVertex2i(308, 278);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110,123,139);
	glVertex2i(315, 278);
	glVertex2i(315, 375);
	glVertex2i(318, 375);
	glVertex2i(318, 278);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110,123,139);
	glVertex2i(325, 278);
	glVertex2i(325, 375);
	glVertex2i(328, 375);
	glVertex2i(328, 278);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110,123,139);
	glVertex2i(352, 300);
	glVertex2i(352, 400);
	glVertex2i(355, 400);
	glVertex2i(355, 300);
    glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110,123,139);
	glVertex2i(373, 300);
	glVertex2i(373, 375);
	glVertex2i(376, 375);
	glVertex2i(376, 300);
    glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110,123,139);
	glVertex2i(400, 300);
	glVertex2i(400, 375);
	glVertex2i(403, 375);
	glVertex2i(403, 300);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110,123,139);
	glVertex2i(430, 300);
	glVertex2i(430, 400);
	glVertex2i(433, 400);
	glVertex2i(433, 300);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110,123,139);
	glVertex2i(300, 300);
	glVertex2i(300, 303);
	glVertex2i(450, 303);
	glVertex2i(450, 300);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110,123,139);
	glVertex2i(300, 330);
	glVertex2i(300, 333);
	glVertex2i(450, 333);
	glVertex2i(450, 330);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110,123,139);
	glVertex2i(300, 360);
	glVertex2i(300, 363);
	glVertex2i(450, 363);
	glVertex2i(450, 360);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(116,187,251);
	glVertex2i(330, 290);
	glVertex2i(330, 300);
	glVertex2i(345, 300);
	glVertex2i(345, 290);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(116,187,251);
	glVertex2i(380, 290);
	glVertex2i(380, 300);
	glVertex2i(398, 300);
	glVertex2i(398, 290);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(116,187,251);
	glVertex2i(355, 315);
	glVertex2i(355, 325);
	glVertex2i(370, 325);
	glVertex2i(370, 315);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(116,187,251);
	glVertex2i(380, 315);
	glVertex2i(380, 325);
	glVertex2i(398, 325);
	glVertex2i(398, 315);
    glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(157, 216, 250);
	glVertex2i(405, 315);
	glVertex2i(405, 325);
	glVertex2i(425, 325);
	glVertex2i(425, 315);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(157, 216, 250);
    glVertex2i(405, 335);
	glVertex2i(405, 355);
	glVertex2i(425, 355);
	glVertex2i(425, 335);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(116,187,251);
	glVertex2i(380, 345);
	glVertex2i(380, 355);
	glVertex2i(398, 355);
	glVertex2i(398, 345);
    glEnd();
	glPopMatrix();

}

void Building2()
{
    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(102, 139, 139);
	glVertex2i(550, 245);
	glVertex2i(550, 390);
	glVertex2i(650, 390);
	glVertex2i(650, 245);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 255);
	glVertex2i(650, 255);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 265);
	glVertex2i(650, 265);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 275);
	glVertex2i(650, 275);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 285);
	glVertex2i(650, 285);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 295);
	glVertex2i(650, 295);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 305);
	glVertex2i(650, 305);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 315);
	glVertex2i(650, 315);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 325);
	glVertex2i(650, 325);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 335);
	glVertex2i(650, 335);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 345);
	glVertex2i(650, 345);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 355);
	glVertex2i(650, 355);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 365);
	glVertex2i(650, 365);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 375);
	glVertex2i(650, 375);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(550, 385);
	glVertex2i(650, 385);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(570,245);
	glVertex2i(570, 390);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(590,245);
	glVertex2i(590, 390);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(610,245);
	glVertex2i(610, 390);
	glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(630,245);
	glVertex2i(630, 390);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(550, 260);
	glVertex2i(550, 270);
	glVertex2i(645, 270);
	glVertex2i(645, 260);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(550, 285);
	glVertex2i(550, 295);
	glVertex2i(645, 295);
	glVertex2i(645, 285);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(550, 310);
	glVertex2i(550, 320);
	glVertex2i(645, 320);
	glVertex2i(645, 310);
    glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(550, 335);
	glVertex2i(550, 345);
	glVertex2i(645, 345);
	glVertex2i(645, 335);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(550, 360);
	glVertex2i(550, 370);
	glVertex2i(645, 370);
	glVertex2i(645, 360);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(550, 390);
	glVertex2i(550, 410);
	glVertex2i(553, 410);
	glVertex2i(553, 390);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(570, 390);
	glVertex2i(570, 410);
	glVertex2i(580, 410);
	glVertex2i(580, 390);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(630, 390);
	glVertex2i(630, 410);
	glVertex2i(640, 410);
	glVertex2i(640, 390);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(550, 395);
	glVertex2i(630, 395);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(550, 400);
	glVertex2i(630, 400);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(600, 390);
	glVertex2i(600, 405);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(605, 390);
	glVertex2i(605, 405);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(610, 390);
	glVertex2i(610, 405);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(615, 390);
	glVertex2i(615, 405);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(620, 390);
	glVertex2i(620, 405);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(625, 390);
	glVertex2i(625, 405);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(630, 390);
	glVertex2i(630, 405);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(635, 390);
	glVertex2i(635, 405);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(640, 390);
	glVertex2i(640, 405);
    glEnd();
	glPopMatrix();

}


void building5(){

   glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(102, 139, 139);
	glVertex2i(1000, 200);
	glVertex2i(1000, 345);
	glVertex2i(1100, 345);
	glVertex2i(1100, 200);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 210);
	glVertex2i(1100, 210);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 220);
	glVertex2i(1100, 220);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 230);
	glVertex2i(1100, 230);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 240);
	glVertex2i(1100, 240);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 250);
	glVertex2i(1100, 250);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 260);
	glVertex2i(1100, 260);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 270);
	glVertex2i(1100, 270);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 280);
	glVertex2i(1100, 280);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 290);
	glVertex2i(1100, 290);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 300);
	glVertex2i(1100, 300);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 310);
	glVertex2i(1000, 310);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 320);
	glVertex2i(1000, 320);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 330);
	glVertex2i(1100, 330);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1000, 340);
	glVertex2i(1100, 340);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1020,200);
	glVertex2i(1020, 345);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1040,200);
	glVertex2i(1040, 345);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1060,200);
	glVertex2i(1060, 345);
	glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(102, 102, 102);
	glVertex2i(1080,200);
	glVertex2i(1080, 345);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(1000, 215);
	glVertex2i(1000, 225);
	glVertex2i(1095, 225);
	glVertex2i(1095, 215);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(1000, 240);
	glVertex2i(1000, 250);
	glVertex2i(1095, 250);
	glVertex2i(1095, 240);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(1000, 265);
	glVertex2i(1000, 275);
	glVertex2i(1095, 275);
	glVertex2i(1095, 265);
    glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(1000, 290);
	glVertex2i(1000, 300);
	glVertex2i(1095, 300);
	glVertex2i(1095, 290);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(1000, 315);
	glVertex2i(1000, 325);
	glVertex2i(1095, 325);
	glVertex2i(1095, 315);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(1000, 345);
	glVertex2i(1000, 365);
	glVertex2i(1003, 365);
	glVertex2i(1003, 345);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(1020, 345);
	glVertex2i(1020, 365);
	glVertex2i(1030, 365);
	glVertex2i(1030, 345);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_POLYGON);
	glColor3ub(110, 123, 139);
	glVertex2i(1080, 345);
	glVertex2i(1080, 365);
	glVertex2i(1090, 365);
	glVertex2i(1090, 345);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(1000, 350);
	glVertex2i(1080, 350);
    glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(1000, 355);
	glVertex2i(1080, 355);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(1050, 345);
	glVertex2i(1050, 360);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(1055, 345);
	glVertex2i(1055, 360);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(1060, 345);
	glVertex2i(1060, 360);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(1065, 345);
	glVertex2i(1065, 360);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(1070, 345);
	glVertex2i(1070, 360);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(1075, 345);
	glVertex2i(1075, 360);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(1080, 345);
	glVertex2i(1080, 360);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(1085, 345);
	glVertex2i(1085, 360);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3ub(110, 123, 139);
	glVertex2i(1090, 345);
	glVertex2i(1090, 360);
    glEnd();
	glPopMatrix();

}
void Tower1()
{
    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(280, 330);
	glVertex2i(280, 360);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(290, 330);
	glVertex2i(290, 360);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(277, 360);
	glVertex2i(277, 365);
	glVertex2i(293, 365);
	glVertex2i(293, 360);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(277, 365);
	glVertex2i(277, 385);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(293, 365);
	glVertex2i(293, 385);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(277, 370);
	glVertex2i(277, 375);
	glVertex2i(293, 375);
	glVertex2i(293, 370);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(277, 380);
	glVertex2i(277, 385);
	glVertex2i(293, 385);
	glVertex2i(293, 380);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(280, 425);
	glVertex2i(280, 385);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(290, 425);
	glVertex2i(290, 385);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(235, 405);
	glVertex2i(400, 405);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(235, 405);
	glVertex2i(400, 405);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(240, 415);
	glVertex2i(270, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(300, 415);
	glVertex2i(390, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(235, 405);
	glVertex2i(240, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(250, 405);
	glVertex2i(240, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(250, 405);
	glVertex2i(260, 415);
	glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(270, 405);
	glVertex2i(260, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(270, 405);
	glVertex2i(270, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(280, 405);
	glVertex2i(270, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(290, 405);
	glVertex2i(300, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(310, 405);
	glVertex2i(300, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(310, 405);
	glVertex2i(320, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(330, 405);
	glVertex2i(320, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(330, 405);
	glVertex2i(340, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(350, 405);
	glVertex2i(340, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(350, 405);
	glVertex2i(360, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(370, 405);
	glVertex2i(360, 415);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(370, 405);
	glVertex2i(380, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(390, 405);
	glVertex2i(380, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(390, 405);
	glVertex2i(390, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(400, 405);
	glVertex2i(390, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(285, 435);
	glVertex2i(280, 425);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(285, 435);
	glVertex2i(290, 425);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(240, 400);
	glVertex2i(240, 415);
	glVertex2i(243, 415);
	glVertex2i(243, 400);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(245, 400);
	glVertex2i(245, 415);
	glVertex2i(248, 415);
	glVertex2i(248, 400);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(249, 400);
	glVertex2i(249, 415);
	glVertex2i(252, 415);
	glVertex2i(252, 400);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(385, 405);
	glVertex2i(385, 395);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(388, 405);
	glVertex2i(388, 395);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(385, 395);
	glVertex2i(388, 395);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(386.5, 395);
	glVertex2i(375, 385);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(386.5, 395);
	glVertex2i(396, 385);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(370, 360);
	glVertex2i(370, 385);
	glVertex2i(400, 385);
	glVertex2i(400, 360);
	glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(117,161,208);
	glVertex2i(375, 365);
	glVertex2i(375, 380);
	glVertex2i(395, 380);
	glVertex2i(395, 365);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(290, 395);
	glVertex2i(280, 385);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(290, 395);
	glVertex2i(280, 400);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(290, 405);
	glVertex2i(280, 400);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(290, 405);
	glVertex2i(280, 410);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(290, 415);
	glVertex2i(280, 410);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(290, 415);
	glVertex2i(280, 420);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(290, 425);
	glVertex2i(280, 420);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(285, 435);
	glVertex2i(250, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(285, 435);
	glVertex2i(390, 415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(280, 330);
	glVertex2i(290, 340);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(280, 350);
	glVertex2i(290, 340);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(280, 350);
	glVertex2i(290, 360);
	glEnd();
	glPopMatrix();

}

void Tower()
{
    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(580, 200);
	glVertex2i(590, 205);
	glVertex2i(605, 205);
	glVertex2i(615, 200);
	glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(214,197,55);
	glVertex2i(590, 205);
	glVertex2i(590, 400);
	glVertex2i(605, 400);
	glVertex2i(605, 205);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(590, 207);
	glVertex2i(590, 213);
	glVertex2i(605, 213);
	glVertex2i(605, 207);
	glEnd();
	glPopMatrix();

///.............../////
	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(166,125,65);
	glVertex2i(593, 215);
	glVertex2i(593, 230);
	glVertex2i(602, 230);
	glVertex2i(602, 215);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(166,125,65);
	glVertex2i(593, 232);
	glVertex2i(593, 247);
	glVertex2i(602, 247);
	glVertex2i(602, 232);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,139,139);
	glVertex2i(593, 249);
	glVertex2i(593, 264);
	glVertex2i(602, 264);
	glVertex2i(602, 249);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,139,139);
	glVertex2i(593, 266);
	glVertex2i(593, 281);
	glVertex2i(602, 281);
	glVertex2i(602, 266);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,139,139);
	glVertex2i(593, 283);
	glVertex2i(593, 298);
	glVertex2i(602, 298);
	glVertex2i(602, 283);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,139,139);
	glVertex2i(593, 300);
	glVertex2i(593, 315);
	glVertex2i(602, 315);
	glVertex2i(602, 300);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,139,139);
	glVertex2i(593, 317);
	glVertex2i(593, 332);
	glVertex2i(602, 332);
	glVertex2i(602,317);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,139,139);
	glVertex2i(593, 334);
	glVertex2i(593, 349);
	glVertex2i(602, 349);
	glVertex2i(602,334);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,139,139);
	glVertex2i(593, 351);
	glVertex2i(593, 366);
	glVertex2i(602, 366);
	glVertex2i(602,351);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,139,139);
	glVertex2i(593, 368);
	glVertex2i(593, 383);
	glVertex2i(602, 383);
	glVertex2i(602,368);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,139,139);
	glVertex2i(593, 385);
	glVertex2i(593, 400);
	glVertex2i(602, 400);
	glVertex2i(602,385);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(214,197,55);
	glVertex2i(590, 400);
	glVertex2i(587, 405);
	glVertex2i(608, 405);
	glVertex2i(605,400);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(214,197,55);
	glVertex2i(587, 405);
	glVertex2i(587, 410);
	glVertex2i(608, 410);
	glVertex2i(608,405);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(587, 410);
	glVertex2i(587, 450);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(608, 410);
	glVertex2i(608, 450);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(214,197,55);
	glVertex2i(587, 415);
	glVertex2i(587, 425);
	glVertex2i(608, 425);
	glVertex2i(608,415);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(214,197,55);
	glVertex2i(587, 430);
	glVertex2i(587, 440);
	glVertex2i(608, 440);
	glVertex2i(608,430);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(214,197,55);
	glVertex2i(585, 440);
	glVertex2i(585, 450);
	glVertex2i(610, 450);
	glVertex2i(610,440);
	glEnd();
	glPopMatrix();

	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(587, 450);
	glVertex2i(587, 490);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(608, 450);
	glVertex2i(608, 490);
	glEnd();
	glPopMatrix();
///.............///

    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(677, 460);
	glVertex2i(677, 480);
	glVertex2i(680, 480);
	glVertex2i(680, 460);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(672, 460);
	glVertex2i(672, 480);
	glVertex2i(675, 480);
	glVertex2i(675, 460);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(667, 460);
	glVertex2i(667, 480);
	glVertex2i(670, 480);
	glVertex2i(670, 460);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(661, 460);
	glVertex2i(661, 480);
	glVertex2i(665, 480);
	glVertex2i(665, 460);
    glEnd();
	glPopMatrix();



	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(580, 480);
	glVertex2i(450, 480);
	glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(615, 480);
	glVertex2i(680, 480);
	glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(214,197,55);
	glVertex2i(445, 470);
	glVertex2i(445, 473);
	glVertex2i(680, 473);
	glVertex2i(680, 470);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(214,197,55);
	glVertex2i(587, 490);
	glVertex2i(597, 510);
	glVertex2i(608, 490);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(593, 215);
	glVertex2i(602, 230);
	glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(593, 247);
	glVertex2i(602, 232);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(593, 249);
	glVertex2i(602, 264);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(593, 281);
	glVertex2i(602, 266);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(593, 283);
	glVertex2i(602, 298);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(593, 315);
	glVertex2i(602, 300);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(593, 317);
	glVertex2i(602, 332);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(593, 349);
	glVertex2i(602,334);
	glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(593, 351);
	glVertex2i(602, 366);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(593, 383);
	glVertex2i(602,368);
	glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(593, 385);
	glVertex2i(602, 400);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(591, 490);
	glVertex2i(591, 410);
	glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(594, 490);
	glVertex2i(594, 410);
	glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(597, 490);
	glVertex2i(597, 410);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(600, 490);
	glVertex2i(600, 410);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(603, 490);
	glVertex2i(603, 410);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(606, 490);
	glVertex2i(606, 410);
	glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(450, 480);
    glVertex2i(445, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(450, 480);
    glVertex2i(460, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(470, 480);
    glVertex2i(460, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(470, 480);
    glVertex2i(480, 470);
    glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(490, 480);
    glVertex2i(480, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(490, 480);
    glVertex2i(500, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(510, 480);
    glVertex2i(500, 470);
    glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(510, 480);
    glVertex2i(520, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(530, 480);
    glVertex2i(520, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(530, 480);
    glVertex2i(540, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(550, 480);
    glVertex2i(540, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(550, 480);
    glVertex2i(560, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(570, 480);
    glVertex2i(560, 470);
    glEnd();
	glPopMatrix();

    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(570, 480);
    glVertex2i(580, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(580, 480);
    glVertex2i(580, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(580, 480);
    glVertex2i(593, 470);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(470, 470);
    glVertex2i(470, 460);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(473, 470);
    glVertex2i(473, 460);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(473, 460);
    glVertex2i(470, 460);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(471, 460);
    glVertex2i(451, 445);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(471, 460);
    glVertex2i(451, 445);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(491, 445);
	glVertex2i(471, 460);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(445, 441);
	glVertex2i(445, 445);
	glVertex2i(498, 445);
	glVertex2i(498, 441);
    glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(615, 480);
	glVertex2i(605, 470);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(615, 480);
	glVertex2i(625, 470);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(635, 480);
	glVertex2i(625, 470);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(635, 480);
	glVertex2i(645, 470);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(655, 480);
	glVertex2i(645, 470);
	glEnd();
	glPopMatrix();


    glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(655, 480);
	glVertex2i(665, 470);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(214,197,55);
	glVertex2i(675, 480);
	glVertex2i(665, 470);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(597, 510);
	glVertex2i(471, 480);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(597, 510);
	glVertex2i(675, 480);
	glEnd();
	glPopMatrix();
}


void building3()
{
    glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(117,155,132);
	glVertex2i(250, 250);
	glVertex2i(250, 280);
	glVertex2i(300, 280);
	glVertex2i(300, 250);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(145,180,156);
	glVertex2i(260, 280);
	glVertex2i(260, 330);
	glVertex2i(300, 330);
	glVertex2i(300, 280);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(250, 330);
	glVertex2i(250, 250);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(260, 330);
	glVertex2i(260, 250);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(290, 330);
	glVertex2i(290, 250);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(250, 280);
	glVertex2i(300, 280);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(250, 260);
	glVertex2i(300, 260);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(250, 300);
	glVertex2i(300, 300);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_LINES);
    glColor3ub(102,102,102);
	glVertex2i(250, 330);
	glVertex2i(300, 330);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(270, 265);
	glVertex2i(270, 280);
	glVertex2i(280, 280);
	glVertex2i(280, 265);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(270, 285);
	glVertex2i(270, 300);
	glVertex2i(280, 300);
	glVertex2i(280, 285);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    glColor3ub(102,102,102);
	glVertex2i(270, 310);
	glVertex2i(270, 325);
	glVertex2i(280, 325);
	glVertex2i(280, 310);
	glEnd();
	glPopMatrix();

}

void Shadow()
{
    glPushMatrix();
	glBegin(GL_POLYGON);
       if (f)glColor3ub(116,187,251);
    else glColor3ub(117,161,208);

	glVertex2i(230, 275);
	glVertex2i(230, 300);
	glVertex2i(260, 300);
	glVertex2i(260, 275);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    if (f)glColor3ub(116,187,251);
    else glColor3ub(117,161,208);

	glVertex2i(240, 300);
	glVertex2i(240, 355);
	glVertex2i(290, 355);
	glVertex2i(290, 300);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    if (f)glColor3ub(116,187,251);
    else glColor3ub(117,161,208);

	glVertex2i(295, 275);
	glVertex2i(295, 380);
	glVertex2i(340, 380);
	glVertex2i(340, 275);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
   if (f)glColor3ub(116,187,251);
    else glColor3ub(117,161,208);

	glVertex2i(345, 275);
	glVertex2i(345,430);
	glVertex2i(390, 430);
	glVertex2i(390, 275);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    if (f)glColor3ub(116,187,251);
    else glColor3ub(117,161,208);

	glVertex2i(350, 275);
	glVertex2i(350,440);
	glVertex2i(380, 440);
	glVertex2i(380, 275);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
   if (f)glColor3ub(116,187,251);
    else glColor3ub(117,161,208);

	glVertex2i(390, 275);
	glVertex2i(390,380);
	glVertex2i(410, 380);
	glVertex2i(410, 275);
	glEnd();
	glPopMatrix();


	glPushMatrix();
	glBegin(GL_POLYGON);
if (f)glColor3ub(116,187,251);
    else glColor3ub(117,161,208);

	glVertex2i(550, 275);
	glVertex2i(550,450);
	glVertex2i(580, 450);
	glVertex2i(580, 275);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
   if (f)glColor3ub(116,187,251);
    else glColor3ub(117,161,208);

	glVertex2i(560, 275);
	glVertex2i(560,460);
	glVertex2i(600, 460);
	glVertex2i(600, 275);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    if (f)glColor3ub(116,187,251);
    else glColor3ub(117,161,208);

	glVertex2i(640, 275);
	glVertex2i(640,410);
	glVertex2i(665, 410);
	glVertex2i(665, 275);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
    if (f)glColor3ub(116,187,251);
    else glColor3ub(117,161,208);

	glVertex2i(650, 275);
	glVertex2i(650,420);
	glVertex2i(665, 420);
	glVertex2i(665, 275);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glBegin(GL_POLYGON);
   if (f)glColor3ub(116,187,251);
    else glColor3ub(117,161,208);

	glVertex2i(660, 275);
	glVertex2i(660,430);
	glVertex2i(665, 430);
	glVertex2i(665, 275);
	glEnd();
	glPopMatrix();


}



///Circle
void circle(GLfloat x, GLfloat y, GLfloat rad){
    GLint triangle_amt=60;
    GLfloat t_pi = 2*PI;
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x,y);
    for(i=0;i<=triangle_amt;i++){
        GLfloat dx=rad*cos(i*t_pi/triangle_amt), dy=rad*sin(i*t_pi/triangle_amt);

        glVertex2f(x+dx,y+dy);
    }
    glEnd();
}

void Tree()
{
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(96,51,17);
    glVertex2i(50,25);
    glVertex2i(90,25);
    glVertex2i(90,200);
    glVertex2i(50,200);

    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glVertex2i(90,80);
    glVertex2i(120,100);
    glVertex2i(120,120);
    glVertex2i(90,100);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glVertex2i(10,25);
    glVertex2i(130,25);
    glVertex2i(60,50);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3f(0.1, 1.293, 0.0);
    glVertex2i(50,20);
    glVertex2i(80,20);
    glVertex2i(70,70);

    glColor3ub(97,179,41);

    glVertex2i(50,20);
    glVertex2i(80,20);
    glVertex2i(30,70);
    glVertex2i(50,20);
    glVertex2i(110,70);
    glVertex2i(80,20);
    glVertex2i(50,20);
    glVertex2i(10,50);
    glVertex2i(80,20);
    glVertex2i(50,20);
    glVertex2i(120,50);
    glVertex2i(80,20);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(0,100,0);
    circle(120,105,15);
    circle(150,115,15);
    circle(140,105,15);
    circle(130,115,15);
    circle(125,110,15);
    circle(150,130,15);
    circle(145,120,15);
    circle(130,130,15);
    circle(125,125,15);
    circle(120,130,15);
    circle(0,230,30);
    circle(0,190,30);
    circle(90,245,30);
    circle(70,250,30);
    circle(140,230,30);
    circle(130,250,30);
    circle(125,200,30);
    circle(150,220,30);
    circle(145,225,30);
    circle(60,230,30);
    circle(40,235,30);
    circle(90,290,30);
    circle(20,195,30);
    circle(40,180,30);
    circle(130,225,30);
    circle(120,215,30);
    circle(50,220,30);
    circle(145,265,30);
    circle(60,290,30);
    circle(40,245,30);
    circle(90,170,30);
    circle(90,190,30);
    glPopMatrix();

}

void plants()
{
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3f(0.1, 1.293, 0.0);
    glVertex2i(150,25);
    glVertex2i(180,25);
    glVertex2i(165,70);
    glColor3ub(97,179,41);
    glVertex2i(150,25);
    glVertex2i(180,25);
    glVertex2i(130,50);
    glVertex2i(150,25);
    glVertex2i(180,25);
    glVertex2i(200,50);
    glVertex2i(150,25);
    glVertex2i(180,25);
    glVertex2i(185,60);
    glVertex2i(150,25);
    glVertex2i(180,25);
    glVertex2i(135,60);
    glEnd();
    glPopMatrix();
}

///Cloud Model-1 Structure
void cloudModel1(){
    if(f)glColor3f(1.25,0.924,0.930);
    else glColor3ub(54,74,156);

    glPushMatrix();
    circle(320,210,15);///Left
    circle(340,225,16);///Top
    circle(360,210,16);///Right
    ///Bottom
    circle(330, 210, 16);
    circle(340, 210, 16);
    circle(350, 210, 16);

    glPopMatrix();

}
///Cloud Model-2 Structure
void cloudModel2(){
    if(f)glColor3f(1.25,0.924,0.930);
    else glColor3ub(54,74,156);

    glPushMatrix();
    circle(305,205,10);///Left
    circle(320,210,15);///Top
    circle(334,207,10);///Right
    circle(320, 207, 10);///Bottom
    glPopMatrix();
}
///cement
/*void cement(){
    glColor3ub(96,96,96);
    glPushMatrix();
    circle(850,750,10);///Left
    circle(865,755,15);///Top
    circle(880,752,10);///Right
    circle(885, 752, 10);///Bottom
    glPopMatrix();


}*/
///Cloud Model-3 Structure
void cloudModel3(){

    glColor3f(1.25,0.924,0.930);

    glPushMatrix();
    circle(300,200,15);///Left
    circle(320,210,15);///Top_Left
    circle(340,220,16);///Top
    circle(360, 210, 15);///Top_Right
    circle(380,200,15);///Right
    circle(360,190,20);///Bottom_Right
    circle(320,190,20);///Bottom_Left
    circle(340,190,20);///Bottom
    glPopMatrix();
}


///Sky
void sky(){
    glPushMatrix();
   if(f)glColor3ub(157, 216, 250);
    else glColor3ub(4, 11, 51);

    glBegin(GL_POLYGON);
    glVertex2i(0,510);
    glVertex2i(1200,510);
    glVertex2i(1200,600);
    glVertex2i(0,600);
    glEnd();
    glPopMatrix();
}


///Sun
void sun(){
        if(f){
        glPushMatrix();
        glColor3ub(252, 212, 64);
        glTranslatef(sun_x,sun_y,0.0);
        circle(200,150,30);
        glPopMatrix();
        }

}




///Moon
void moon(){
    if(!f){
        glPushMatrix();
        glColor3ub(240,248,255);
        circle(620,500,30);
        glColor3ub(4, 11, 51);
        circle(630,520,30);
        glPopMatrix();
    }
}
///Stars
void star(){
    if(!f){
        glPushMatrix();
        glColor3ub(255,255,255);
        glPointSize(4);
        glBegin(GL_POINTS);

        glVertex2i(100,500);
        glVertex2i(120,520);
        glVertex2i(150,550);
        glVertex2i(170,570);
        glVertex2i(200,530);
        glVertex2i(230,570);
        glVertex2i(350,560);
        glVertex2i(900,500);
        glVertex2i(580,570);
        glVertex2i(840,560);
        glVertex2i(750,500);
        glVertex2i(950,500);
        glVertex2i(760,520);
        glVertex2i(690,550);
        glVertex2i(550,570);
        glVertex2i(790,530);
        glVertex2i(830,570);
        glVertex2i(690,560);
        glVertex2i(590,500);
        glVertex2i(490,530);
        glVertex2i(330,570);
        glVertex2i(390,560);
        glVertex2i(460,500);
        glVertex2i(490,550);
        glVertex2i(30,570);
        glVertex2i(390,560);
        glVertex2i(460,500);
        glVertex2i(400,530);
        glVertex2i(930,570);
        glVertex2i(990,560);
        glVertex2i(960,500);
        glVertex2i(460,520);
        glVertex2i(220,570);
        glVertex2i(30,570);
        glVertex2i(290,560);
        glVertex2i(240,580);
        glVertex2i(700,550);
        glVertex2i(90,530);
        glVertex2i(600,570);
        glVertex2i(590,560);
        glVertex2i(1180,500);
        glVertex2i(900,500);
        glVertex2i(800,530);
        glVertex2i(1160,570);
        glVertex2i(900,560);
        glVertex2i(800,500);

        glVertex2i(1000,500);
        glVertex2i(1050,500);
        glVertex2i(1180,450);
        glVertex2i(1150,550);
        glVertex2i(1111,444);
        glVertex2i(1122,460);
        glVertex2i(1122,500);
        glVertex2i(1100,560);
        glVertex2i(900,510);
        glVertex2i(850,520);
        glVertex2i(1126,530);
        glVertex2i(950,560);
        glVertex2i(820,590);
        glEnd();
        glPopMatrix();
    }
}
void night()
{
    if(!f){
        glClearColor(15.0f/255.0f,20.0/255.0f,50.0/255.0f,0.0);
    }


    glFlush();
}






///cloud1
void cloud1(){
    if(f){
        glPushMatrix();
        glTranslatef(cpos1,350,0);
        cloudModel1();
        glPopMatrix();
    }
}

void sound(){

    //PlaySound("f.wav", NULL, SND_ASYNC|SND_FILENAME);
    PlaySound("f.wav", NULL,SND_ASYNC|SND_FILENAME|SND_LOOP);

}

///cloud2
void cloud6(){
    if(f){
        glPushMatrix();
        glTranslatef(cpos2,270,0);
        cloudModel2();
        glPopMatrix();
    }
}
///cloud3
void cloud3(){
    if(f){
        glPushMatrix();
        glTranslatef(cpos3,300,0);
        cloudModel3();
        glPopMatrix();
    }
}
///cloud4
void cloud4(){
    glPushMatrix();
    glTranslatef(cpos4,350,0);
    cloudModel2();
    glPopMatrix();
}

///cloud5
void cloud5(){
    glPushMatrix();
    glTranslatef(cpos5,420,0);
    cloudModel1();
    glPopMatrix();
}

///cloud2
void cloud2(){
    glPushMatrix();
    glTranslatef(cpos2,320,0);
    cloudModel1();
    glPopMatrix();
}

void car1()
{
    glPushMatrix();
    glTranslatef(pos_car1, 0.0, 0.0);

    glPushMatrix();
    ///car body
    glBegin(GL_POLYGON);
    glColor3ub(25, 149, 104);
    glVertex2f(600,130);
    glVertex2f(800,130);
    glVertex2f(800,170);
    glVertex2f(600,170);
    glEnd();


    // rotator box
    glBegin(GL_POLYGON);
    glColor3ub(0, 1, 0);
    glVertex2f(730,170);
    glVertex2f(750,170);
    glVertex2f(750,175);
    glVertex2f(730,175);
    glEnd();


    // driver box
    glBegin(GL_POLYGON);
    //glColor3ub(284, 102, 84);
    glColor3ub(214, 148, 0);
    glColor3ub(4, 54, 84);
    glVertex2f(780 ,175);
    glVertex2f(790,180);
    glVertex2f(790,190);
    glVertex2f(785,200);
    glVertex2f(705,200);
    glVertex2f(705,175);
    glEnd();


    // carane hand
    glBegin(GL_POLYGON);
    glColor3ub(214, 148, 0);
    glVertex2f(710,200);
    glVertex2f(750,200);
    glVertex2f(790,300);
    glVertex2f(760,300);
    glEnd();

    // carane feet
    glBegin(GL_POLYGON);
    glColor3ub(214, 148, 0);
    glVertex2f(765,300);
    glVertex2f(785,300);
    glVertex2f(850,350);
    glVertex2f(870,348);
    glEnd();


    // carane nee
    glBegin(GL_POLYGON);
    glColor3f(255, 0, 0);
    glVertex2f(845,355);
    glVertex2f(860,358);
    glVertex2f(880,340);
    glVertex2f(853,340);
    glEnd();

    //wire 1
    glBegin(GL_POLYGON);
    glColor3f(0, 0, 0);
    glVertex2f(860,340);
    glVertex2f(863,340);
    glVertex2f(860,300);
    glVertex2f(863,300);
    glEnd();


    //wire 2
    glBegin(GL_POLYGON);
    glColor3f(0, 0, 0);
    glVertex2f(867,340);
    glVertex2f(870,340);
    glVertex2f(867,300);
    glVertex2f(870,300);
    glEnd();
// change bo

    glBegin(GL_POLYGON);
    glColor3f(0, 0, 0);
    glVertex2f(855,300);
    glVertex2f(875,300);
    glVertex2f(875,285);
    glVertex2f(855,285);
    glEnd();



    // arrow down

    glBegin(GL_POLYGON);
    glColor3f(0, 0, 0);
    glVertex2f(862,285);
    glVertex2f(867,285);
    glVertex2f(867,270);
    glVertex2f(862,270);
    glEnd();


     // arrow up

    glBegin(GL_POLYGON);
    glColor3f(0, 0, 0);
    glVertex2f(875,270);
    glVertex2f(862,270);
    glVertex2f(857,280);
    glVertex2f(860,280);
    glEnd();



     // object

    glBegin(GL_POLYGON);
    glColor3ub(249, 149, 51);
    glVertex2f(800,250);
    glVertex2f(900,250);
    glVertex2f(900,220);
    glVertex2f(800,220);
    glEnd();

     // object binding 1

    glBegin(GL_POLYGON);
    glColor3f(0, 0, 0);
    glVertex2f(863,270);
    glVertex2f(866,270);
    glVertex2f(853,250);
    glVertex2f(847,250);
    glEnd();

     // object binding 2

    glBegin(GL_POLYGON);
    glColor3f(0, 0, 0);
     glVertex2f(863,270);
    glVertex2f(866,270);
    glVertex2f(870,250);
    glVertex2f(867,250);
    glEnd();


    //extra object 1
    glBegin(GL_POLYGON);
    glColor3ub(237, 179, 20);
     glVertex2f(590,170);
    glVertex2f(680,170);
    glVertex2f(685,185);
    glVertex2f(595,185);
    glEnd();

     //extra object 2
    glBegin(GL_POLYGON);
    glColor3ub(116, 161, 97);
     glVertex2f(600,185);
    glVertex2f(690,185);
    glVertex2f(695,200);
    glVertex2f(605,200);
    glEnd();

     //extra object 3
    glBegin(GL_POLYGON);
    glColor3ub(249, 149, 51);
     glVertex2f(595,200);
    glVertex2f(685,200);
    glVertex2f(680,215);
    glVertex2f(590,215);
    glEnd();

    ///Window_Rear
    glBegin(GL_POLYGON);
    if(f) glColor3ub(204, 255, 204);
    else glColor3ub(225, 235, 0);
    glVertex2f(710,175);
    glVertex2f(760,175);
    glVertex2f(740,195);
    glVertex2f(710,195);
    glEnd();


    ///car 1st wheel
    glBegin(GL_POLYGON);
    glColor3ub(0, 0, 0);
    circle(675,140,15);

	glBegin(GL_POLYGON);
    glColor3ub(255, 200, 218);
    circle(675,140,4);

	///car 2nd wheel
	glBegin(GL_POLYGON);
    glColor3ub(0, 0, 0);
    circle(740,140,15);

    glBegin(GL_POLYGON);
    glColor3ub(255, 200, 218);
    circle(740,140,4);

    glPopMatrix();

    glPopMatrix();
}

void moving_car1(int value)
{
    if (pos_car1 < -1000)
        pos_car1 = 500;

    pos_car1 -= car1_speed;
    glutPostRedisplay();
    glutTimerFunc(10, moving_car1, 0);
}


void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(255.0,0.0,1.0);

	Field();

	Road();
	Field2();
  soil();
	sky();
	sun();
	moon();
	star();

    cloud1();
    cloud2();
    cloud3();
    cloud4();
    cloud5();
    cloud6();
    Shadow();

    building();
    Building2();
    Tower1();
  Tower();
	Building1();
	building5();
//cement();
    building();
    building2();
building3();
  car1();
    Tree();
    plants();

	glFlush();
	glutSwapBuffers();
}

void update(int value){

    ///Cloud Control
    if(cpos1>750)cpos1=-320;
    if(cpos2<-350)cpos2=650;
    if(cpos3>750)cpos3=-320;
    if(cpos4>750)cpos4=-320;
    if(cpos5<-350)cpos5=650;
    cpos1+=sp1;
    cpos2-=sp1;
    cpos3+=sp1;
    cpos4+=sp1;
    cpos5-=sp1;
    ///Sun Control
    if(sun_y>480){
        sun_x=650;
        sun_y=360;
        f=0;
        night();
    }

    sun_x-=sp_x;
    sun_y+=sp_y;

    glutTimerFunc(100, update, 0);
    glutPostRedisplay();
}


float _rain = 0.0f;
bool rainday = false;
void Rain(int value)
{
    if (rainday)
    {
        _rain += 0.01f;

        glBegin(GL_POINTS);
        for (int i = 1; i <= 1000; i++)
        {
            int x = rand(), y = rand();
            x %= 1200;
            y %= 600;
            glBegin(GL_LINES);
            glColor3f(1.0, 1.0, 1.0);
            glVertex2d(x, y);
            glVertex2d(x + 3, y + 3);
            glEnd();
        }

        glutPostRedisplay();
        glutTimerFunc(5, Rain, 0);
        glFlush();
    }
}
void handleKeypress(unsigned char key, int x, int y){
	switch (key){

	     ///Switch Day and Night Modes
        case 'd':
            f=1;
            glClearColor(157.0f/255.0f, 216.0f/255.0f, 250.0f/255.0f, 1.0);
            break;
        case 'n':
            f=0;
            glutIdleFunc(night);
            break;

            ///Rain controls
        case 'a':
            rainday = true;
            Rain(_rain);
            break;
        case 'c':
            rainday = false;
            break;

         ///red car controls
	    case 'f':
        car1_speed += 1;
        break;

        case 'b':
        car1_speed -= 1 ;
        break;

        case 'h':
        car1_speed = 0;
        break;
            glutPostRedisplay();

	}
}

int main(int argc, char** argv)
{


    cout << "///// SCENE CONTROLS /////" << endl;
    cout << "Press 'N' to switch to night mode." << endl;
    cout << "Press 'D' to switch to day mode." << endl;
    cout << "Press 'A' to start raining." << endl;
    cout << "Press 'C' to stop raining.\n" << endl;

     cout << "///// CRANE CONTROLS /////" << endl;
    cout << "Press 'F' to speed up car." << endl;
    cout << "Press 'B' to slow down car." << endl;
    cout << "Press 'H' to stop the car." << endl;
    cout << "Press 'B' to go backwards.\n" << endl;

    glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowPosition(50, 50);
	glutInitWindowSize(1200, 600);
	glutCreateWindow("Graphics Project");
	init();
	glutDisplayFunc(display);
    glutKeyboardFunc(handleKeypress);
    glutTimerFunc(100, update, 0);
    glutTimerFunc(1000, moving_car1, 0);
    sound();
    glutMainLoop();
}
